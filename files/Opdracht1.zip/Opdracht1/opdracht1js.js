console.log("opdr 1.1")
console.log("Hello World!\n\n")


console.log("opdr 1.2")
for (let index = 0; index < 10; index++) {
    console.log(index)
}
console.log("\n\n")


console.log('opdr 1.3')
var mijnauto = {
    merk: "Ford",
    type: "Mondeo",
    aantalwielen: 4,
    kleur: "blauw"
}
console.log(mijnauto.kleur + "\n\n")
